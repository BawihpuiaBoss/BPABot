</p>
<p align="center">
  <a href="https://chat.whatsapp.com/JIJplkiYyrFE4dyFGade43">
    <img alt=Support height="350" src="https://telegra.ph/file/a6b9bbde7feaa92c69c7b.jpg"> 
    </p>
<h1 align="center">    KING-MULTI-DEVICE (BETA)
</h1>
<p align="center"> 
  
<p align="center"> A Whatsapp Bot Create By Naveed Dogar To Do Everything That Is Possible On WhatsApp
 
  </a>
</p>
<p align="center">
<a href="https://github.com/naveeddogar"><img title="Author" src="https://img.shields.io/badge/KING_MD-MULTI_DEVICE-black?style=for-the-badge&logo=github"></a>
<p/>



---  

</p>


   <p align="left">
  <a href="https://github.com/naveeddogar/KING-MD/fork">
    <img src="https://img.shields.io/github/forks/naveeddogar/KING-MD?label=Fork&style=social">
  <p align="left"> 
  <a href="https://github.com/naveeddogar/KING-MD/stargazers">
    <img src="https://img.shields.io/github/stars/naveeddogar/KING-MD?style=social">
      
  
 

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{naveeddogar}/count.svg" alt="naveeddogar :: Visitor's Count" /></p>
<p align="center">
 <a href="https://whatsapp.com/channel/0029Va66s2IJENxvTJjUtM1w" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/ Whatsapp Support Channel -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>
</p>

<a href="https://whatsapp.com/channel/0029Va66s2IJENxvTJjUtM1w"><img alt="WhatsApp" src="https://img.shields.io/badge/-Whatsapp%20Channel-yellow?style=for-the-badge&logo=whatsapp&logoColor=black"/></a>


# DEPLOY SETUP


## 1 *`⨷ FORK THIS REPO`*
<a href='https://github.com/naveeddogar/KING-MD/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork This Repo-black?style=for-the-badge&logo=git&logoColor=white'/></a>

## 2 *`⨷ SCAN QR`*
<a href='https://king-md-qr-genrator.vercel.app/' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Scan Qr code-black?style=for-the-badge&logo=opencv&logoColor=white'/></a>

## *`⨷ NOW DEPLOY`*

#### DEPLOY TO HEROKU 

1. If You don't have a account in Heroku. Create a account.
    <br>
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>

2. Now Deploy
    <br>
<a href='https://heroku.com/deploy' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>

#### DEPLOY TO CODESPACE

1. If You don't have a account in Codespace. Create a account.
    <br>
<a href='https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fcodespaces' target="_blank"><img alt='Codespaces' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=visualstudiocode' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=visualstudiocode' width="96.35" height="28"/></a></p>


#### DEPLOY TO RAILWAY

1. If You don't have a account in Railway. Create a account.
    <br>
<a href='https://railway.app/login' target="_blank"><img alt='Railway' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=railway' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=railway' width="96.35" height="28"/></a></p>

#### DEPLOY TO MONGENIUS

1. If You don't have a account in Mongenius. Create a account.
    <br>
<a href='https://studio.mogenius.com/user/registration' target="_blank"><img alt='Mongenius' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=genius' width="96.35" height="28"/></a></p>

2. Now Deploy
    <br>
<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=genius' width="96.35" height="28"/></a></p>


#### DEPLOY TO REPLIT

1. If You don't have a account in Replit. Create a account.
    <br>
<a href='https://replit.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=replit&logoColor=white'/></a>

2. Now Deploy
    <br>
<a href='https://replit.com/github/naveeddogar/KING-MD' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Deploy-black?style=for-the-badge&logo=replit&logoColor=white'/></a>

---


<h2 align="center"> Star This Repo If You like KING-MD🌟
</h2>

#### Thanks To 

1: Suhail Bro

2: Zubair Bro

3: SamPandy Bro

#### NOTE: DON'T MODIFY THIS BOT FIRST INFORM THE OWNER
