while true
do
echo "Starting KING-MD..."
node lib/client.js
done
